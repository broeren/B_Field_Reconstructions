#ifndef GKYL_IPOW_H 
#define GKYL_IPOW_H 

extern "C" { 

double gkyl_ipow(double base, int exp);

} 
#endif
