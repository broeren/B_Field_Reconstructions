Gkyl uses some libraries written by others. All of these are open
source. The documentation for the various libraries are at:

Date: https://github.com/Tieske/date

cxxopts: https://github.com/jarro2783/cxxopts
