See [Tinker Cliffs](https://arc.vt.edu/tinkercliffs/) for
details on the machine.

This simulation was run on a AMD EPYC 7702 chip, using 128 cores.
