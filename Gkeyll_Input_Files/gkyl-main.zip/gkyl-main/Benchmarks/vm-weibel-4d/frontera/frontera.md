See [Frontera](https://www.tacc.utexas.edu/systems/frontera) for
details on the machine.

This simulation was run on a Cascade Lake (Intel Xeon Platinum 8280)
chip, using 56 cores.
