-- File with list of regression tests considered to be "mother"
-- test. (MOAT : Mother of All Tests)
return {
   "./vm-weibel/rt-weibel-1x2v-p1.lua",
   "./gk-sheath/rt-gk-sheath-1x2v-p1.lua",
}
