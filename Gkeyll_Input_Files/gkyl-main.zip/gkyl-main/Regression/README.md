# Regression Testing

Tests in this directory run whole simulations to test the App
system. These simulations test comprehensive capabilities of the code,
not just a single updater. Each test directory contains one or more
input file for a particular system of interest.
