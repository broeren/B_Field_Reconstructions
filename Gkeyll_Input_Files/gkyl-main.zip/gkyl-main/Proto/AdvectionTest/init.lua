-- Gkyl ------------------------------------------------------------------------
--
-- Dispatch into the recovery advection testing modules
--    _______     ___
-- + 6 @ |||| # P ||| +
--------------------------------------------------------------------------------

-- Gkyl modules
local Advection = require "Proto.AdvectionTest.advection"

return Advection
