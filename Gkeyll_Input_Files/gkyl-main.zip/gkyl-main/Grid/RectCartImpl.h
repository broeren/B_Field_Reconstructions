#ifndef RECT_CART_IMPL_H
#define RECT_CART_IMPL_H

extern "C" {
   void cellCenter(int ndim, double* lower, int* currIdx, double* dx, double* xc);
}

#endif // RECT_CART_IMPL_H
